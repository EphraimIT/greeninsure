package greeninsure;

/**
 * Created by developer-ocansey on 3/02/17.
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class start {
    public static void main(String[] args) {
        SpringApplication.run(start.class, args);
    }
}
